package cn.wwj.dao;

import cn.wwj.po.Role;

public interface RoleDao {

	Role getRoleById(Integer id);

}
