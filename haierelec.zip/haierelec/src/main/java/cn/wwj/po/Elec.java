package cn.wwj.po;

public class Elec {
	private Integer id;
	private String title;
	
}
